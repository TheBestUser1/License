#!/usr/bin/env python3
import argparse

parser = argparse.ArgumentParser(description='custom descriptor')
parser.add_argument('-f',help='in file for decrypt', required=True)
parser.add_argument('-key', help='key for decrypt',default=114,type =int)
parser.add_argument('-out',help='out file',default='out')
args = parser.parse_args()



with open(args.f,"rb")as f:
    decrypted = bytearray(f.read())
    for i in range(0,len(decrypted)):
        decrypted[i]=0xff&decrypted[i] -args.key - i
    with open(args.out,'wb') as p:
        p.write(decrypted)

