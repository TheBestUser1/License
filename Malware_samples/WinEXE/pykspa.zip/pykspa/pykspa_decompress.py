#!/usr/bin/env python3

import r2pipe


r2 = r2pipe.open("pykspa.exe")


def auto_analyze(r2):
    r2.cmd("aaa")

def get_xref(r2):
    return r2.cmd("ax~section..data:0[1]").strip("\n")
     
def get_function(r2,address):
    f_offset = r2.cmd(f"pd 2 @ {address}~:1[4] ").strip("\n")
    return f_offset

def get_multiple_refs(r2,address):
    addrs = r2.cmd(f"axt @ {address}~[1]").split("\n")
    del addrs[-1]
    return addrs

def write_to_file(size,addr,name):
    r2.cmd(f"wtf {name} {size} @ {addr}")




def dump_things(r2,address):
    nr = 0
    for i in address:
       push_commands = r2.cmd(f"pd -2 @ {i} ~[4]").split("\n")
       del push_commands[-1]
       write_to_file(push_commands[0],push_commands[1],f"dump{nr}")   
       nr+=1

def main():
    auto_analyze(r2)
    
    addr=get_xref(r2)
    f_addr=get_function(r2,addr)
    refs = get_multiple_refs(r2,f_addr)
    dump_things(r2,refs)


if __name__=='__main__':
    main()

